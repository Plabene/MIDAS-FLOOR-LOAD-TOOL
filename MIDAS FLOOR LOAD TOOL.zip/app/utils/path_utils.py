from __future__ import annotations

from pathlib import Path
import sys


def project_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_filename(value: str, max_len: int = 120) -> str:
    text = str(value or "").strip() or "unnamed"
    invalid = '<>:"/\\|?*\n\r\t'
    for ch in invalid:
        text = text.replace(ch, "_")
    text = "_".join(text.split())
    return text[:max_len].strip("._ ") or "unnamed"
